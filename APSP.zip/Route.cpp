#include "Route.h"

Route::Route()
{
	distance = 0;
}

void Route::addLocation(int location) {
	path.push_back(location);
	size++;
}

vector<int> Route::getPath() {
	return path;
}

double Route::getDistance() {
	return distance;
}

void Route::setDistance(int value) {
	distance = value;
}

int Route::getSize() {
	return size;
}

void Route::print() {
	for (int i = 0; i < path.size() - 1; ++i) {
		cout << path[i] << " > ";
	}
	cout << path[path.size() - 1];
}
