#pragma once
#include <vector>
#include <iostream>

using std::vector;
using std::cout;

class Route
{
private:
	vector<int> path;
	int size;
	double distance;

public:
	Route();

	void addLocation(int);
	vector<int> getPath();
	double getDistance();
	void setDistance(int);
	int getSize();
	void print();

};

