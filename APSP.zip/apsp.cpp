#include <omp.h>
#include <iostream>
#include <algorithm>
#include <chrono>
#include "matrix.hpp"
#include "Route.h"

using std::cin;
using std::cout;
using std::endl;
using std::cerr;
using std::vector;
using std::min;
using std::chrono::high_resolution_clock;
using std::chrono::nanoseconds;
using std::chrono::duration_cast;
using namespace my;

int main(int argc, char *argv[]) {
	int numLocations;
	cin >> numLocations;
	int numRoads;
	cin >> numRoads;

	//Map with all paths between locations.
	matrix<double> map(numLocations, numLocations);
	//Assigns roads to the map.
	for (int i = 0; i < numRoads; ++i) {
		int start;
		cin >> start;
		int end;
		cin >> end;
		double length;
		cin >> length;

		map[start][end] = length;
	}

	for (int i = 0; i < numLocations; ++i) {
		for (int j = 0; j < numLocations; ++j) {
			if (map[i][j] == 0) {
				map[i][j] = std::numeric_limits<double>::infinity();
			}
		}
	}

	int numRoutes;
	cin >> numRoutes;
	//Vector containing all routes specified.
	vector<Route> routes(numRoutes);
	for (int i = 0; i < numRoutes; ++i) {
		//Num locations visited in the route.
		int numLocs;
		cin >> numLocs;
		for (int j = 0; j < numLocs; ++j) {
			//Location visited on the route.
			int loc;
			cin >> loc;
			routes[i].addLocation(loc);
		}
	}

	double minRoute = std::numeric_limits<double>::infinity();	
#pragma omp parallel
	{ //Parallel region start.

		//Calculations
		for (int k = 0; k < numLocations; ++k) {
			for (int i = 0; i < numLocations; i++) {
				#pragma omp for
				for (int j = 0; j < numLocations; j++) {
					map[i][j] = min(map[i][j], map[i][k] + map[k][j]);
				}
			}
		}

		#pragma omp single
		{
			for (int i = 0; i < numLocations; ++i) {
				map[i][i] = 0;
			}
		}
	
		//Calculate distance for each route.
		#pragma omp for
		for (int i = 0; i < routes.size(); ++i) {
			double distance = 0;
			vector<int> r = routes[i].getPath();
			for (int j = 0; j < r.size() - 1; ++j) {
				int start = r[j];
				int end = r[j + 1];
				double addThis = map[start][end];
				distance += addThis;
			}
			routes[i].setDistance(distance);

			#pragma omp critical
			{
				minRoute = min(distance, minRoute);
			}
		}

	} //Parallel region end

	 

	for (int i = 0; i < routes.size(); ++i) {
		cout << routes[i].getDistance() << endl;
	}
	cout << minRoute << endl;
}