#pragma once
#include <iostream>
#include <mpi.h>
#include "matrix.hpp"

using my::matrix;
using std::cin;
using std::cout;
using std::endl;
using std::swap;

//Gets the input necessary to create the initial sheet.
void get_input(matrix<double>&, int&, int& );

//Sets the initial values for each process' chunks.
void initializeChunks(matrix<double>, matrix<double>&, int, int, int, int, int);

//Shares all values in the matrix is is given with other processes who need it.
void shareMyChunk(matrix<double>&, int, int, int, int);

//Takes the average of all inner cells and places it in the second matrix it is given.
void advance(matrix<double>, matrix<double>&);

//Takes in a matrix and copies it into the value of the second one it is given.
void copyChunk(matrix<double>, matrix<double>&);

//Checks to see if the program has reached the desired precision.
void checkFinished(matrix<double>, matrix<double>, bool&);

//Gathers all the data from the processes to process 0.
void collectResults(matrix<double>&, matrix<double>, int, int);


int main(int argc, char *argv[]) {
	MPI_Init(&argc, &argv);

	int myRank;
	MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
	int numprocs;
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

	int numRows;
	int numCols;
	int numRowsPerProc;

	bool finished = false;

	matrix<double> sheet;
	matrix<double> myChunk;
	matrix<double> myScratch;

	//get numrows and cols
	//set the size of sheet to m+2 and n+2
	//Get the input in process 0 and fill out the sheet.
	if (myRank == 0) {
		get_input(sheet, numRows, numCols);
	}

	//Share all the input data with processes.
	MPI_Bcast(&numRows, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&numCols, 1, MPI_INT, 0, MPI_COMM_WORLD);
	
	//Update sizes of the chunks processes will receive.
	numRowsPerProc = numRows / numprocs;
	myChunk.resize(numRowsPerProc + 2, numCols + 2);
	myScratch.resize(numRowsPerProc + 2, numCols + 2);


	initializeChunks(sheet, myChunk, numRowsPerProc, numRows, numCols, myRank, numprocs);
	copyChunk(myChunk, myScratch);

	while (!finished) {
		advance(myChunk, myScratch);
		shareMyChunk(myScratch, numCols, numRowsPerProc, myRank, numprocs);
		swap(myChunk, myScratch);
		checkFinished(myChunk, myScratch, finished);
	}

	collectResults(sheet, myChunk, numRowsPerProc, numCols);
	
	if (myRank == 0) {
		cout << sheet;
	}

	if (myRank == 0) {
		cin >> numCols;
	}
	MPI_Barrier(MPI_COMM_WORLD);

	MPI_Finalize();
}

void get_input(matrix<double>& sheet, int& numRows, int& numCols) {
	int numHeatSources;
	cin >> numRows >> numCols >> numHeatSources;
	sheet.resize(numRows + 2, numCols + 2);
	for (int i = 0; i < numHeatSources; ++i) {
		int r1, c1, r2, c2;
		double heatValue;
		cin >> r1 >> c1 >> r2 >> c2 >> heatValue;
		//Assigns the heat value the the areas required.
		for (int rindex = 0; rindex < numRows + 2; ++rindex) {
			for (int cindex = 0; cindex < numCols + 2; ++cindex) {
				if (rindex >= r1 && rindex <= r2 && cindex >= c1 && cindex <= c2) {
					sheet[rindex][cindex] = heatValue;
				}
			}
		}
	}
}

void initializeChunks(matrix<double> sheet, matrix<double>& chunk, int numRowsPerProc, int numRows, int numCols, int myRank, int numprocs) {
	MPI_Scatter(sheet[1], numRowsPerProc * (numCols + 2), MPI_DOUBLE, chunk[1], numRowsPerProc * (numCols + 2), MPI_DOUBLE, 0, MPI_COMM_WORLD);
	if (myRank == 0) {
		for (int i = 0; i < numCols + 2; ++i) {
			chunk[0][i] = sheet[0][i];
		}
		MPI_Send(sheet[numRows + 1], numCols + 2, MPI_DOUBLE, numprocs - 1, 0, MPI_COMM_WORLD);
	}
	else if (myRank == numprocs - 1) {
		MPI_Recv(chunk[numRowsPerProc + 1], numCols + 2, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}

	shareMyChunk(chunk, numCols, numRowsPerProc, myRank, numprocs);
}

void shareMyChunk(matrix<double>& calculatedChunk, int numCols, int numRowsPerProc, int myRank, int numprocs) {
	if (myRank % 2 == 0) {
		if (myRank == 0) {
			MPI_Recv(calculatedChunk[numRowsPerProc + 1], numCols + 2, MPI_DOUBLE, myRank + 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			MPI_Send(calculatedChunk[numRowsPerProc], numCols + 2, MPI_DOUBLE, myRank + 1, 0, MPI_COMM_WORLD);		
		}
		else {
			MPI_Recv(calculatedChunk[numRowsPerProc + 1], numCols + 2, MPI_DOUBLE, myRank + 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			MPI_Recv(calculatedChunk[0], numCols + 2, MPI_DOUBLE, myRank - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

			MPI_Send(calculatedChunk[1], numCols + 2, MPI_DOUBLE, myRank - 1, 0, MPI_COMM_WORLD);
			MPI_Send(calculatedChunk[numRowsPerProc], numCols + 2, MPI_DOUBLE, myRank + 1, 0, MPI_COMM_WORLD);
		}
	}

	if (myRank % 2 == 1) {
		if (myRank == numprocs - 1) {
			MPI_Send(calculatedChunk[1], numCols + 2, MPI_DOUBLE, myRank - 1, 0, MPI_COMM_WORLD);
			MPI_Recv(calculatedChunk[0], numCols + 2, MPI_DOUBLE, myRank - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		}
		else {
			MPI_Send(calculatedChunk[1], numCols + 2, MPI_DOUBLE, myRank - 1, 0, MPI_COMM_WORLD);
			MPI_Send(calculatedChunk[numRowsPerProc], numCols + 2, MPI_DOUBLE, myRank + 1, 0, MPI_COMM_WORLD);

			MPI_Recv(calculatedChunk[numRowsPerProc + 1], numCols + 2, MPI_DOUBLE, myRank + 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			MPI_Recv(calculatedChunk[0], numCols + 2, MPI_DOUBLE, myRank - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		}
	}
}

void advance(matrix<double> myChunk, matrix<double>& myScratch) {
	for (size_t i = 1; i < myScratch.num_rows() - 1; ++i) {
		for (size_t j = 1; j < myScratch.num_cols() - 1; ++j) {
			myScratch[i][j] = (myChunk[i - 1][j] + myChunk[i + 1][j] + myChunk[i][j - 1] + myChunk[i][j + 1])/ 4;
			double db = myScratch[i][j];

		}
	}
}

void copyChunk(matrix<double> myChunk, matrix<double>& myScratch) {
	for (size_t i = 0; i < myScratch.num_rows(); ++i) {
		for (size_t j = 0; j < myScratch.num_cols(); ++j) {
			myScratch[i][j] = myChunk[i][j];
		}
	}
}

void checkFinished(matrix<double> myChunk, matrix<double> myScratch, bool& finished) {
	int myResult = 1;
	int result;
	for (size_t i = 1; i < myScratch.num_rows() - 1; ++i) {
		for (size_t j = 1; j < myScratch.num_cols() - 1; ++j) {
			if ((myScratch[i][j] - myChunk[i][j]) > 0.000001 || (myScratch[i][j] - myChunk[i][j]) < -0.000001) {
				myResult = 0;
			}
		}
	}
	MPI_Allreduce(&myResult, &result, 1, MPI_INT, MPI_BAND, MPI_COMM_WORLD);

	if (result == 1) {
		finished = true;
	}
}

void collectResults(matrix<double>& sheet, matrix<double> myChunk, int numRowsPerProc, int numCols) {
	MPI_Gather(myChunk[1], numRowsPerProc * (numCols + 2), MPI_DOUBLE, sheet[1], numRowsPerProc * (numCols + 2), MPI_DOUBLE, 0, MPI_COMM_WORLD);
}
