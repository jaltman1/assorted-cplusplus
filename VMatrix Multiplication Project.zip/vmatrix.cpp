#include <iostream>
#include <mpi.h>
#include <vector>
#include "matrix.hpp"

using namespace std;
using namespace my;

int main(int argc, char *argv[]) {
	MPI_Init(&argc, &argv);

	// Process id number
	int id;
	MPI_Comm_rank(MPI_COMM_WORLD, &id);

	// Number of processes
	int numprocs;
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

	//Set num rows to the number of processes.
	int numRows;
	int numColumns;

	matrix<double> mat;
	vector<double> factor;
	matrix<double> myColumn;
	vector<double> myCalculatedValue;

	vector<char> myBuffer(sizeof(int) * 2);
	int myPosition = 0;

	if (id == 0) {
		//Get number of columns
		cin >> numRows;
		cin >> numColumns;

		mat.resize(numRows, numColumns);
		factor.resize(numColumns);
		//Read in matrix in row major order rows x columns amount.
		for (int i = 0; i < numRows; ++i) {
			cin >> factor[i];
		}
		for (int i = 0; i < numRows; ++i) {
			for (int j = 0; j < numColumns; ++j) {
				cin >> mat[i][j];
			}
		}

		MPI_Pack(&numRows, 1, MPI_INT, myBuffer.data(), sizeof(int) * 2, &myPosition, MPI_COMM_WORLD);
		MPI_Pack(&numColumns, 1, MPI_INT, myBuffer.data(), sizeof(int) * 2, &myPosition, MPI_COMM_WORLD);
	}

	//Broadcast numrows and numColumns
	MPI_Bcast(myBuffer.data(), sizeof(int) * 2, MPI_PACKED, 0, MPI_COMM_WORLD);

	if (id != 0) {
		MPI_Unpack(myBuffer.data(), sizeof(int) * 2, &myPosition, &numRows, 1, MPI_INT, MPI_COMM_WORLD);
		MPI_Unpack(myBuffer.data(), sizeof(int) * 2, &myPosition, &numColumns, 1, MPI_INT, MPI_COMM_WORLD);
	}
	int numColsPerProc = numColumns / numprocs;

	if (id != 0) {
		mat.resize(numRows, numColumns);
		factor.resize(numRows);
	}
	myColumn.resize(numRows, numColsPerProc);
	myCalculatedValue.resize(numColsPerProc);

	MPI_Bcast(&factor[0], numRows, MPI_DOUBLE, 0, MPI_COMM_WORLD);

	MPI_Datatype Standalone_Column_Type;
	MPI_Type_vector(numRows, 1, numColumns, MPI_DOUBLE, &Standalone_Column_Type);

	MPI_Datatype Column_Type_for_matrix;
	MPI_Type_create_resized(Standalone_Column_Type, 0, sizeof(double), &Column_Type_for_matrix);
	MPI_Type_commit(&Column_Type_for_matrix);
	
	MPI_Scatter(mat[0], numColsPerProc, Column_Type_for_matrix, myColumn[0], numRows * numColsPerProc, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	

	for (int i = 0; i < numColsPerProc; ++i) {
		for (int j = 0; j < numRows; ++j) {
			myCalculatedValue[i] += factor[j] * myColumn[i][j];
		}
	}

	vector<double> resultVector(numColumns);
	MPI_Gather(&myCalculatedValue[0], numColsPerProc, MPI_DOUBLE, &resultVector[0], numColsPerProc, MPI_DOUBLE, 0, MPI_COMM_WORLD);

	if (id == 0) {
		for (int i = 0; i < resultVector.size(); ++i) {
			cout << resultVector[i] << " ";
		}
		cout << endl;
	}
	MPI_Finalize();
}